#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include "../header/student.h"
#include "../header/stuadd.h"
#include "../header/studel.h"
#include "../header/stumod.h"
#include "../header/studis.h"
#include "../header/stusearch.h"
#include "../header/stuattendadd.h"
#include "../header/stuattendview.h"



int main()
{
	int op;
	char ch;
	
	while(1)
	{
		printf("\n--------------------------------------------------------");
		printf("\n           Student Management Application");
		printf("\n--------------------------------------------------------");
		printf("\n\nMenu :");
		printf("\n----\n");
		printf("\n1.Add Student .\n2.Delete Student .\n3.Modify Student .\n4.Display Student .\n5.Search Student .\n6.Store Student Attendence .\n7.Display Student Attendence .\n8.Exit .");
		printf("\n\n\tEnter Option : ");
		scanf("%d",&op);
		switch(op)
		{
			case 1: stuAdd(); fflush(stdin); getch(); system("cls"); break;
			case 2: stuDel(); fflush(stdin); getch(); system("cls"); break;
			case 3: stuMod(); fflush(stdin); getch(); system("cls"); break; 
			case 4: stuDis(); fflush(stdin); getch(); system("cls"); break;
			case 5: stuSearch(); fflush(stdin); getch(); system("cls"); break;
			case 6: system("cls"); stuAttendAdd(); fflush(stdin); getch(); system("cls"); break;
			case 7: system("cls"); stuAttendView(); fflush(stdin); getch(); system("cls"); break;
			case 8: printf("\n\n\t\tThank You For using \"Student Management Application\"\n\t\t-----------------------------------------------------\n");
					getch();
					exit(0);
			
			
			default : printf("Wrong input !!"); fflush(stdin); getch(); system("cls"); break;
		}
	}
	
	
	return 0;
}
