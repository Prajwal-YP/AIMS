struct student
{
	int rollno,cls;
	char sec;
	char name[20];
	float avg;
};

struct attend
{
	int rollno;
	char ans,name[20];
};
