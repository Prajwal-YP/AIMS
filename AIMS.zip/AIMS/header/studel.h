void stuDel()
{
	struct student s;
	FILE *fp1,*fp2;
	int keyno;
	char record='n';
	fp1=fopen("student.dat","rb");
	fp2=fopen("temp.dat","wb");
	
	if(fp1==NULL)
	{
		printf("\nSTUDENT FILE NOT EXISTS !!");
		return;
	}
	
	printf("\nEnter Student Roll Number to Delete : ");
	scanf("%d",&keyno);
	
	while(fread(&s,sizeof(s),1,fp1)==1)
	{
		if(keyno==s.rollno)
		{
			record='y';
			break;
		}
	}
	if(record=='n')
	{
		printf("\nStudent Not Found !!");	
		printf("\n\t\t\t\t\t\t------------------------------------------------");	
		printf("\n\t\t\t\t\t\t . . . . . . Thank You,Delete Again . . . . . . ");	
		printf("\n\t\t\t\t\t\t------------------------------------------------\n\n");
	}
	else
	{
		printf("\nSEARCH FOUND : ");
		printf("\n------------");	
		printf("\n\n\t\t\t\t\t\tStudent Roll Number     :\t%d",s.rollno);
		printf("\n\t\t\t\t\t\tStudent Name            :\t%s",s.name);
		printf("\n\t\t\t\t\t\tStudent Class           :\t%d",s.cls);
		printf("\n\t\t\t\t\t\tStudent Section         :\t%c",s.sec);
		printf("\n\t\t\t\t\t\tStudent Average Marks   :\t%.2f",s.avg);
		
		rewind(fp1);
	
		while(fread(&s,sizeof(s),1,fp1)==1)
		{
			if(keyno!=s.rollno)
			{
				fwrite(&s,sizeof(s),1,fp2);
			}
		}
		fclose(fp1);
		fclose(fp2);
		remove("student.dat");
		system("ren temp.dat student.dat");	
		printf("\nStudent Data Successfully Deleted !!");
		
		fp1=fopen("student.dat","rb");
	
		printf("\n\n\t\t\t\t\t\tStudent Details Update !!");
	 	printf("\n\t\t\t\t\t\t----------------------");
		while(fread(&s,sizeof(s),1,fp1)==1)
		{
			printf("\n\n\t\t\t\t\t\tStudent Roll Number     :\t%d",s.rollno);
			printf("\n\t\t\t\t\t\tStudent Name            :\t%s",s.name);
			printf("\n\t\t\t\t\t\tStudent Class           :\t%d",s.cls);
			printf("\n\t\t\t\t\t\tStudent Section         :\t%c",s.sec);
			printf("\n\t\t\t\t\t\tStudent Average Marks   :\t%.2f",s.avg);
			printf("\n\t\t\t\t\t\t------------------------------------------------");
		}
		printf("\n\t\t\t\t\t\t . . . . . . Thank You,Delete Again . . . . . . . ");	
		printf("\n\t\t\t\t\t\t------------------------------------------------\n\n");
		fclose(fp1);
	}
}
