void registersv (int op)
{
	struct attend a;
	int m,cls;
	char sec,answer[10]="",des[30]="",dd[3]="",mm[4]="",yy[5]="",date[12]="";
	
	if(op==1)
	{
		cls=8;
		sec='a';
		strcpy(des,"class/8/a/");
	}
	else if(op==2)
	{
		cls=8;
		sec='b';
		strcpy(des,"class/8/b/");
		
	}
	else if(op==3)
	{
		cls=8;
		sec='c';
		strcpy(des,"class/8/c/");
		
	}
	else if(op==4)
	{
		cls=9;
		sec='a';
		strcpy(des,"class/9/a/");
		
	}
	else if(op==5)
	{
		cls=9;
		sec='b';
		strcpy(des,"class/9/b/");
	}
		
	else if(op==6)
	{
		cls=9;
		sec='c';
		strcpy(des,"class/9/c/");
	}
		
	else if(op==7)
	{
		cls=10;
		sec='a';
		strcpy(des,"class/10/a/");
	}
		
	else if(op==8)
	{
		cls=10;
		sec='b';
		strcpy(des,"class/10/b/");
		
	}
	else
	{
		cls=10;
		sec='c';
		strcpy(des,"class/10/c/");
	}
	printf("\n\nEnter Day\t\t:\t");
	fflush(stdin);
	scanf("%s",dd);
	printf("Enter Month\t\t:\t");
	scanf("%d",&m);
	printf("Enter Year\t\t:\t");
	fflush(stdin);
	scanf("%s",yy);
	
	
	switch(m)
	{
		case 1: strcpy(mm,"Jan"); break;
		case 2: strcpy(mm,"Feb"); break;
		case 3: strcpy(mm,"Mar"); break;
		case 4: strcpy(mm,"Apr"); break;
		case 5: strcpy(mm,"May"); break;
		case 6: strcpy(mm,"Jun"); break;
		case 7: strcpy(mm,"Jul"); break;
		case 8: strcpy(mm,"Aug"); break;
		case 9: strcpy(mm,"Sep"); break;
		case 10: strcpy(mm,"Oct"); break;
		case 11: strcpy(mm,"Nov"); break;
		case 12: strcpy(mm,"Dec"); break;
		
	}
	
	date[0]=mm[0];
	date[1]=mm[1];
	date[2]=mm[2];
	date[3]=' ';
	if(dd[0]=='0')
		date[4]=' ';
	else
		date[4]=dd[0];
	date[5]=dd[1];
	date[6]=' ';
	date[7]=yy[0];
	date[8]=yy[1];
	date[9]=yy[2];
	date[10]=yy[3];
	date[11]='\0';

	strcpy(des,strcat(des,date));
	strcpy(des,strcat(des,".dat"));
	
	FILE *fp1;
	fp1=fopen(des,"rb");
	system("cls");
	printf("ATTENDENCE OF CLASS %d \'%c\'",cls,sec);
	printf("\n---------------------------------");
	
	if(fp1==NULL)
	{
		printf("\n\n\t\t----------------------------------------------------------------");
		printf("\n\t\tNo Student-Attendence Record Found in this class at %s",date);
		printf("\n\t\t----------------------------------------------------------------\n");
		
		return;
	}
	
	printf("\n\n\t-------------------------------------------");
	printf("\n\tRoll_No.\t\tName\t\t:\tAttendence");
	printf("\n\t-------------------------------------------");
	
	while(fread(&a,sizeof(a),1,fp1)==1)
	{
		if(a.ans=='p' || a.ans=='P')
			strcpy(answer,"Present");
		else
			strcpy(answer,"Absent");
		printf("\n\t%d.\t\t%s\t\t:\t%s",a.rollno,a.name,answer);			
	}		
	printf("\n\n\t\t--------------------------------------------------------------------");
	printf("\n\t\t<<\tThis is the End of Class %d \'%c\' Attendence-Record .\t>>",cls,sec);
	printf("\n\t\t--------------------------------------------------------------------\n");
	fclose(fp1);
}


void stuAttendView()
{
	int op,cls;
	char sec;
	
	while(!(op>=1 && op<=9))
	{
		printf("\n----------------------------------------");
		printf("\n       Available Classes Menu");
		printf("\n       ----------------------");
		printf("\n(1)  8 \'a\'\t(2)  8 \'b\'\t(3)  8 \'c\'");
		printf("\n(4)  9 \'a\'\t(5)  9 \'b\'\t(6)  9 \'c\'");
		printf("\n(7) 10 \'a\'\t(8) 10 \'b\'\t(9) 10 \'c\'");
		printf("\n----------------------------------------");
		printf("\nEnter Class Option : ");
		scanf("%d",&op);
	}
			
	registersv(op);
}
