void registers(int op)
{
	struct student s;
	struct attend a;
	int cls;
	char sec,des[100],ispresent,found='n';
	
	if(op==1)
	{
		cls=8;
		sec='a';
		strcpy(des,"class/8/a/");
	}
	else if(op==2)
	{
		cls=8;
		sec='b';
		strcpy(des,"class/8/b/");
		
	}
	else if(op==3)
	{
		cls=8;
		sec='c';
		strcpy(des,"class/8/c/");
		
	}
	else if(op==4)
	{
		cls=9;
		sec='a';
		strcpy(des,"class/9/a/");
		
	}
	else if(op==5)
	{
		cls=9;
		sec='b';
		strcpy(des,"class/9/b/");
	}
		
	else if(op==6)
	{
		cls=9;
		sec='c';
		strcpy(des,"class/9/c/");
	}
		
	else if(op==7)
	{
		cls=10;
		sec='a';
		strcpy(des,"class/10/a/");
	}
		
	else if(op==8)
	{
		cls=10;
		sec='b';
		strcpy(des,"class/10/b/");
		
	}
	else
	{
		cls=10;
		sec='c';
		strcpy(des,"class/10/c/");
	}
	
	strcpy(des,strcat(des,__DATE__));
	strcpy(des,strcat(des,".dat"));
	printf("\n\n%s\n\n",des);
	FILE *fp1,*fp2;
	fp1=fopen(des,"wb");
	fp2=fopen("student.dat","rb");
	system("cls");
	printf("ATTENDENCE OF CLASS %d \'%c\'",cls,sec);
	printf("\n---------------------------------");
	printf("\n\n\t(\'p\' for present || \'a\' for absent)\n");
	printf("\n\t-------------------------------------------");
	printf("\n\tRoll_No.\t\tName\t\t:\tAttendence");
	printf("\n\t-------------------------------------------");
	while(fread(&s,sizeof(s),1,fp2)==1)
	{
		if(s.cls==cls && s.sec==sec)
		{
			found='y';
			while(1)
			{
				printf("\n\t%d.\t\t%s\t\t:\t",s.rollno,s.name);
				fflush(stdin);
				scanf("%c",&ispresent);
				if(ispresent=='a' ||ispresent=='A' ||ispresent=='p' ||ispresent=='P')
					break;
			}
			a.rollno=s.rollno;
			strcpy(a.name,s.name);
			a.ans=ispresent;
			fwrite(&a,sizeof(a),1,fp1);
		}
	}
	if(found=='n')
	{
		printf("\n\n\tNo Students are there in this class !!\n\n");
		return;
	}		
	printf("\n\n\t\t-------------------------------------------------------------------");
	printf("\n\t\t<<\tClass %d \'%c\' Attendence-Record is  Successfuly Saved .\t>>",cls,sec);
	printf("\n\t\t-------------------------------------------------------------------\n");
	fclose(fp1);
	fclose(fp2);
}

void stuAttendAdd()
{
	
	int op,cls;
	char sec;
	
	while(!(op>=1 && op<=9))
	{
		printf("\n----------------------------------------");
		printf("\n       Available Classes Menu");
		printf("\n       ----------------------");
		printf("\n(1)  8 \'a\'\t(2)  8 \'b\'\t(3)  8 \'c\'");
		printf("\n(4)  9 \'a\'\t(5)  9 \'b\'\t(6)  9 \'c\'");
		printf("\n(7) 10 \'a\'\t(8) 10 \'b\'\t(9) 10 \'c\'");
		printf("\n----------------------------------------");
		printf("\nEnter Class Option : ");
		scanf("%d",&op);
	}
			
	registers(op);
}
