void stuDis()
{
	struct student s;
	
	FILE *fp;
	fp=fopen("student.dat","rb");
	
	while(fread(&s,sizeof(s),1,fp)==1)
	{
		printf("\n\n\t\t\t\t\t\tStudent Roll Number     :\t%d",s.rollno);
		printf("\n\t\t\t\t\t\tStudent Name            :\t%s",s.name);
		printf("\n\t\t\t\t\t\tStudent Class           :\t%d",s.cls);
		printf("\n\t\t\t\t\t\tStudent Section         :\t%c",s.sec);
		printf("\n\t\t\t\t\t\tStudent Average Marks   :\t%.2f",s.avg);
		printf("\n\t\t\t\t\t\t------------------------------------------------");
	}
	printf("\n\t\t\t\t\t\t . . . . . . Thank You,Visit Again . . . . . . . ");	
	printf("\n\t\t\t\t\t\t------------------------------------------------\n\n");
	fclose(fp);
}
