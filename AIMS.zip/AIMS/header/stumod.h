void stuMod()
{
	struct student s,newrecord;
	
	int keyno,op=0;
	char record='n';
	FILE *fp;
	fp=fopen("student.dat","rb+");
	
	if(fp==NULL)
	{
		printf("\nFile NOT FOUND !!");
		return;
	}
	
	printf("\nEnter Roll Number of a student to modify : ");
	scanf("%d",&keyno);
	
	while(fread(&s,sizeof(s),1,fp)==1)
	{
		if(keyno==s.rollno)
		{
			record='y';
			break;
		}
	}
	if(record=='n')
	{
		printf("\nStudent with Roll-Number %d NOT FOUND !!",keyno);
	}
	else
	{
		printf("\nSEARCH FOUND : ");
		printf("\n------------");	
		printf("\n\n\t\t\t\t\t\tStudent Roll Number     :\t%d",s.rollno);
		printf("\n\t\t\t\t\t\tStudent Name            :\t%s",s.name);
		printf("\n\t\t\t\t\t\tStudent Class           :\t%d",s.cls);
		printf("\n\t\t\t\t\t\tStudent Section         :\t%c",s.sec);
		printf("\n\t\t\t\t\t\tStudent Average Marks   :\t%.2f",s.avg);
		
		newrecord.rollno=keyno;
		printf("\nEnter new Student Name          :\t");
		fflush(stdin);
		gets(newrecord.name);
		
		while(!(op>=1 && op<=9))
		{
			printf("\n----------------------------------------");
			printf("\n       Available Classes Menu");
			printf("\n       ----------------------");
			printf("\n(1)  8 \'a\'\t(2)  8 \'b\'\t(3)  8 \'c\'");
			printf("\n(4)  9 \'a\'\t(5)  9 \'b\'\t(6)  9 \'c\'");
			printf("\n(7) 10 \'a\'\t(8) 10 \'b\'\t(9) 10 \'c\'");
			printf("\n----------------------------------------");
			printf("\nEnter new Class Option : ");
			scanf("%d",&op);
		}
		
		switch(op)
		{
			case 1:
				newrecord.cls=8;
				newrecord.sec='a';
				break;
			case 2:
				newrecord.cls=8;
				newrecord.sec='b';
				break;
			case 3:
				newrecord.cls=8;
				newrecord.sec='c';
				break;
			case 4:
				newrecord.cls=9;
				newrecord.sec='a';
				break;
			case 5:
				newrecord.cls=9;
				newrecord.sec='b';
				break;
			case 6:
				newrecord.cls=9;
				newrecord.sec='c';
				break;
			case 7:
				newrecord.cls=10;
				newrecord.sec='a';
				break;
			case 8:
				newrecord.cls=10;
				newrecord.sec='b';
				break;
			case 9:
				newrecord.cls=10;
				newrecord.sec='c';
				break;					
		}
		
		printf("\nEnter new Student Average Marks :\t");
		scanf("%f",&newrecord.avg);
		
	 	fseek(fp,-sizeof(s),SEEK_CUR);
	 	fwrite(&newrecord,sizeof(newrecord),1,fp);
	 	
	 	rewind(fp);
	 	
	 	printf("\n\nStudent Details Update !!");
	 	printf("\n----------------------");
	 	while(fread(&s,sizeof(s),1,fp)==1)
		{
			printf("\n\n\t\t\t\t\t\tStudent Roll Number     :\t%d",s.rollno);
			printf("\n\t\t\t\t\t\tStudent Name            :\t%s",s.name);
			printf("\n\t\t\t\t\t\tStudent Class           :\t%d",s.cls);
			printf("\n\t\t\t\t\t\tStudent Section         :\t%c",s.sec);
			printf("\n\t\t\t\t\t\tStudent Average Marks   :\t%.2f",s.avg);
			printf("\n\t\t\t\t\t\t------------------------------------------------");
 		}	
	 	
	}
	printf("\n\t\t\t\t\t\t . . . . . . Thank You,Modify Again . . . . . . ");	
	printf("\n\t\t\t\t\t\t------------------------------------------------\n\n");
	fclose(fp);
}
