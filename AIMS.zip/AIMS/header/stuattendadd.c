#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>

struct student
	{
		int rollno,cls;
		char sec;
		char name[20];
		float avg;
	};
	struct student s;

struct attend
{
	int rollno;
	char ans;
}a;

void registers(int op)
{
	int cls;
	char sec,des[100],ispresent;
	
	if(op==1)
	{
		cls=8;
		sec='a';
		strcpy(des,"class/8/a/");
	}
	else if(op==2)
	{
		cls=8;
		sec='b';
		strcpy(des,"class/8/b/");
		
	}
	else if(op==3)
	{
		cls=8;
		sec='c';
		strcpy(des,"class/8/c/");
		
	}
	else if(op==4)
	{
		cls=9;
		sec='a';
		strcpy(des,"class/9/a/");
		
	}
	else if(op==5)
	{
		cls=9;
		sec='b';
		strcpy(des,"class/9/b/");
	}
		
	else if(op==6)
	{
		cls=9;
		sec='c';
		strcpy(des,"class/9/c/");
	}
		
	else if(op==7)
	{
		cls=10;
		sec='a';
		strcpy(des,"class/10/a/");
	}
		
	else if(op==8)
	{
		cls=10;
		sec='b';
		strcpy(des,"class/10/b/");
		
	}
	else
	{
		cls=10;
		sec='c';
		strcpy(des,"class/10/c/");
	}
	
	strcpy(des,strcat(des,__DATE__));
	strcpy(des,strcat(des,".dat"));
	printf("\n\nPATH : %S\n\n",des);
	FILE *fp1,*fp2;
	fp1=fopen(des,"wb");
	fp2=fopen("student.dat","rb");
	system("cls");
	printf("ATTENDENCE OF CLASS %d \'%c\'",cls,sec);
	printf("\n---------------------------------");
	printf("\n\n\t(\'p\' for present || \'a\' for absent )");
	while(fread(&s,sizeof(s),1,fp2)==1)
	{
		if(s.cls==cls && s.sec==sec)
		{
			while(1)
			{
				printf("\n\t%d.\t%s\t:\t");
				fflush(stdin);
				scanf("%c",&ispresent);
				if(ispresent=='a' ||ispresent=='A' ||ispresent=='p' ||ispresent=='P')
					break;
			}
			a.rollno=s.rollno;
			a.ans=ispresent;
			fwrite(&a,sizeof(a),1,fp1);
		}
	}
	printf("\nClass %d \'%c\' Attendence-Record is  Successfuly Saved .",cls,sec);
	fclose(fp1);
	fclose(fp2);
}

main()
{
	
	int op,cls;
	char sec;
	
	while(!(op>=1 && op<=9))
	{
		printf("\n----------------------------------------");
		printf("\n       Available Classes Menu");
		printf("\n       ----------------------");
		printf("\n(1)  8 \'a\'\t(2)  8 \'b\'\t(3)  8 \'c\'");
		printf("\n(4)  9 \'a\'\t(5)  9 \'b\'\t(6)  9 \'c\'");
		printf("\n(7) 10 \'a\'\t(8) 10 \'b\'\t(9) 10 \'c\'");
		printf("\n----------------------------------------");
		printf("\nEnter Class Option : ");
		scanf("%d",&op);
	}
			
	registers(op);
}
