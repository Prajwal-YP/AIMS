void stuAdd()
{
	struct student s;
	
	int op=0;
	char ch='y';
	FILE *fp;
	fp=fopen("student.dat","ab");

	printf("\nEnter Student Details Below :");
	printf("\n---------------------------");

	while(ch=='y' || ch=='Y')
	{
		system("cls");
		printf("\n\nEnter student Roll Number    :\t");
		scanf("%d",&s.rollno);
	
		printf("\nEnter student Name           :\t");
		fflush(stdin);
		gets(s.name);
		
		while(!(op>=1 && op<=9))
		{
			printf("\n----------------------------------------");
			printf("\n       Available Classes Menu");
			printf("\n       ----------------------");
			printf("\n(1)  8 \'a\'\t(2)  8 \'b\'\t(3)  8 \'c\'");
			printf("\n(4)  9 \'a\'\t(5)  9 \'b\'\t(6)  9 \'c\'");
			printf("\n(7) 10 \'a\'\t(8) 10 \'b\'\t(9) 10 \'c\'");
			printf("\n----------------------------------------");
			printf("\nEnter Class Option : ");
			scanf("%d",&op);
		}
		
		switch(op)
		{
			case 1:
				s.cls=8;
				s.sec='a';
				break;
			case 2:
				s.cls=8;
				s.sec='b';
				break;
			case 3:
				s.cls=8;
				s.sec='c';
				break;
			case 4:
				s.cls=9;
				s.sec='a';
				break;
			case 5:
				s.cls=9;
				s.sec='b';
				break;
			case 6:
				s.cls=9;
				s.sec='c';
				break;
			case 7:
				s.cls=10;
				s.sec='a';
				break;
			case 8:
				s.cls=10;
				s.sec='b';
				break;
			case 9:
				s.cls=10;
				s.sec='c';
				break;					
		}
		op=0;
		
		printf("\nEnter student average Marks  :\t");
		scanf("%f",&s.avg);
	
		fwrite(&s,sizeof(s),1,fp);
		printf("\n1 - Student Record is  Successfuly Saved .");
		
		
	
		printf("\nDO YOU WANT TO ADD 1 MORE STUDENT RECORD(Y/N) ?");
		fflush(stdin);
		ch=getche();
	}
	
	fclose(fp); 						//Closes the File Pointer
	printf("\n\n-------------------------------------------------------\n\n");
}
